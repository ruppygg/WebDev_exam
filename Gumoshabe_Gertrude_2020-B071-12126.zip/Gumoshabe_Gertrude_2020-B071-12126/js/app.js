const current__year = new Date().getFullYear();
const my_year = document.querySelector("#current__year");

my_year.innerHTML = current__year;